
// document.querySelector(".img2").setAttribute("src", imagesList[randomNumber2]);
// if(randomNumber1>randomNumber2){
//     document.querySelector("h1").textContent = "🚩 Player 1 wins!!";
// }
// else if(randomNumber1<randomNumber2){
//     document.querySelector("h1").textContent = "Player 2 wins!! 🚩";
// }
// else{
//     document.querySelector("h1").textContent = "Draw !!!!";
// }
document.querySelector("#roll").addEventListener("click", function(){
    var randomNumber1 = Math.floor(Math.random()*6);
    var randomNumber2 = Math.floor(Math.random()*6);
    var imagesList = ["../Dicee Challenge - Starting Files/images/dice1.png", "../Dicee Challenge - Starting Files/images/dice2.png", "../Dicee Challenge - Starting Files/images/dice3.png", "../Dicee Challenge - Starting Files/images/dice4.png", "../Dicee Challenge - Starting Files/images/dice5.png", "../Dicee Challenge - Starting Files/images/dice6.png"];
// document.querySelector(".img1").setAttribute("src", imagesList[randomNumber1]);
    document.querySelector(".img1").setAttribute("src", imagesList[randomNumber1]);
    document.querySelector(".img2").setAttribute("src", imagesList[randomNumber2]);
    if(randomNumber1>randomNumber2){
        document.querySelector("h1").textContent = "🚩 Player 1 wins!!";
    }
    else if(randomNumber1<randomNumber2){
        document.querySelector("h1").textContent = "Player 2 wins!! 🚩";
    }
    else{
        document.querySelector("h1").textContent = "Draw !!!!";
    }
})